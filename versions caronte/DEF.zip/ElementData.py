# -*- coding: utf-8 -*-
"""
ElementData.py : ** REQUIRED ** El vostre codi de la classe ElementData.
"""
import numpy
import eyed3
import sys
import cfg
import os


class ElementData:
    __slots__ = ["_title", "_artist", "_album", "_genre", "_duration", "_filename"]

    def __init__(self, title = None, filename = None, artist = None, album = None, genre = None, duration = None):
        self._title = title
        self._artist = artist
        self._album = album
        self._genre = genre
        self._duration = duration
        self._filename = filename
        
    def load_MetaData(self):
        metadata = eyed3.load(self._filename)
        if metadata is None:
            print("ERROR: Arxiu MP3 erroni!")
            del self
        title = metadata.tag.title
        self._title = title if title is not None else 'None'
        artist = metadata.tag.artist
        self._artist = artist if artist is not None else 'None'
        album = metadata.tag.album
        self._album = album if album is not None else 'None'
        self._duration = int(numpy.ceil(metadata.info.time_secs))
        
        try:
            genre = metadata.tag.genre.name
        except Exception:
            self._genre = "None"
        else:
            self._genre = genre

    def print(self):
        print(f'''
#============================| {self.title} |=======================#
Duració: \t{self.duration} segons
Artista: \t{self.artist}
Àlbum:   \t{self.album}
Gènere: \t{self.genre}           
''')
        
    def print(self):
        print('ha', end='')
    
    def __hash__(self):
        return hash(self._filename)
    
    def __eq__(self, altre):
        return self._filename == altre.filename
    
    def __ne__(self, altre):
        return self._filename != altre.filename
    
    def __lt__(self, altre):
        return self._filename < altre.filename
        
    title = property(lambda self: self._title, lambda self, nou_atr: setattr(self, '_title', nou_atr))
    artist = property(lambda self: self._artist, lambda self, nou_atr: setattr(self, '_artist', nou_atr))
    album = property(lambda self: self._album, lambda self, nou_atr: setattr(self, '_album', nou_atr))
    genre = property(lambda self: self._genre, lambda self, nou_atr: setattr(self, '_genre', nou_atr))
    duration = property(lambda self: self._duration, lambda self, nou_atr: setattr(self, '_duration', nou_atr))
    filename = property(lambda self: self._filename)
