from MusicData import MusicData

# ==== FUNC 6 ====
class SearchMetadata():
    __slots__ = '_musicData'
    
    def __init__(self, MD):
        if not isinstance(MD, MusicData): raise ValueError("Inicialitza aquesta classe amb un objecte MusicData")
        self._musicData: MusicData = MD

        
    def title(self, sub: str):
        if sub is None or not isinstance(sub, str): return []
        sub = sub.lower()
        uuids_out = []
        for uuid in self._musicData:
            title =  self._musicData.get_title(uuid)
            if title:
                title = title.lower()
                if title.find(sub) != -1:
                    uuids_out.append(uuid)
        
        return uuids_out if uuids_out else []
            
    def artist(self, sub: str):
        if sub is None or not isinstance(sub, str): return []
        sub = sub.lower()
        uuids_out = []
        for uuid in self._musicData:
            artist =  self._musicData.get_artist(uuid)
            if artist:
                artist = artist.lower()
                if artist.find(sub) != -1:
                    uuids_out.append(uuid)
        return uuids_out if uuids_out else []
    
    def genre(self, sub: str):
        if sub is None or not isinstance(sub, str): return []
        sub = sub.lower()
        uuids_out = []
        for uuid in self._musicData:
            title =  self._musicData.get_genre(uuid)
            if title:
                title = title.lower()
                if title.find(sub) != -1:
                    uuids_out.append(uuid)
        return uuids_out if uuids_out else []
    
    def album(self, sub: str):
        if sub is None or not isinstance(sub, str): return []
        sub = sub.lower()
        uuids_out = []
        for uuid in self._musicData:
            title =  self._musicData.get_album(uuid)
            if title:
                title = title.lower()
                if title.find(sub) != -1:
                    uuids_out.append(uuid)
        return uuids_out if uuids_out else []
        
    
    def and_operator(self, list1: list, list2: list):    
        return [uuid for uuid in list1 if uuid in list2]
        
    
    def or_operator(self, list1: list, list2: list):  
        return [uuid for uuid in list1 if uuid not in list2] + \
            [uuid for uuid in list2 if uuid not in list1] 
    
        
    '''
    def get_similar(self, uuid, max_list):
        # musicdata -> self._musicData
        try:
            A_rank = self._musicData.get_song_rank(uuid)/2
            semblanca = []
            for song in self._musicData:
                if song == uuid:
                    continue
                else:
                    AB_value, AB_nodes = self._musicData.get_song_distance(uuid, song)
                    BA_value, BA_nodes = self._musicData.get_song_distance(song, uuid)
                    AB, BA = 0, 0
                    if AB_nodes != 0:
                        AB = (AB_value/AB_nodes) * (A_rank)
                    if BA_nodes != 0:
                        BA = (BA_value/BA_nodes) * (self._musicData.get_song_rank(song)/2)
                    semblanca.append((AB+BA, song))
                
            semblanca.sort(reverse=True)
            semblanca = list(filter(lambda x: x[0] > 0, semblanca))
            print(len(semblanca), uuid[:2])
            l =  list(map(lambda x: x[1], semblanca[:max_list]))[:max_list]
            print(len(l))
            return l
        except Exception as e:
            print("ERROR:", e)
              
    '''          
    
    def return_w_info(self, l_uuids: list, sub: str, name: str):
        if not l_uuids:
            print(f"\nNo songs found for attribute [{name}] : {sub}")
        else:
            out_l = []
            print(f"- {len(l_uuids)} songs found for attribute [{name}] : {sub}")
            for uuid in l_uuids:
                attr_value = self._musicData.get_attribute(uuid, 'title')
                print(f"UUID: {uuid[:12]}... | Title: {attr_value}")
                out_l.append(attr_value)
            return out_l
            
    def get_topfive(): ...
    
    def __repr__(self):
        return 'SearchMetadata(self._musicData: MusicData = MD)'
    