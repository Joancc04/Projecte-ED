# -*- coding: utf-8 -*-
"""
GrafHash.py : ** REQUIRED ** El vostre codi de la classe GrafHash.
"""
import copy
from ElementData import ElementData
import math

class GrafHash:
    """Graf amb Adjacency Map structure"""

    class Vertex:
        __slots__ = '_valor'

        def __init__(self, x: ElementData):
            self._valor=x
                  
        def __str__(self):
            return str(self._valor)
        
        def __eq__(self, v):
            return self._valor.filename == v.filename
            
        def __ne__(self, v):
            return self._valor.filename != v.filename

        data = property(lambda self: self._valor)
            
################################Definicio Class _Vertex  

    __slots__ = '_nodes', '_out', '_in'
    def __init__(self, ln=[],lv=[],lp=[],digraf=False):
        """Crea graf (no dirigit per defecte, digraf si dirigit es True.
        """
        self._nodes = { }
        self._out = { }
        self._in = { } if digraf else self._out
              
        for n in ln:
            v=self.insert_vertex(n)
        if lp==[]:
            for v in lv:
                self.insert_edge(v[0],v[1])
        else:
            for vA,pA in zip(lv,lp):
                self.insert_edge(vA[0],vA[1],pA)
    
    def es_digraf(self):
        return self._out!=self._in
            
    def insert_vertex(self, uuid, x: ElementData):
        if isinstance(x, ElementData):
            v= self.Vertex(x)
            self._nodes[uuid] = v
            self._out[uuid] = {}
            if self.es_digraf():
                self._in[uuid] = {}
            return v
        else:
            return None

    def insert_edge(self, uuid1: str, uuid2: str, p1=1):        
        if uuid1 in self._nodes and uuid2 in self._nodes:
            if uuid2 in self._out[uuid1]:
                self._out[uuid1][uuid2] += p1
                self._in[uuid2][uuid1] += p1
            else:
                self._out[uuid1][uuid2] = 0
                self._in[uuid2][uuid1] = 0
        
       
    def vertices(self):
        """Return una iteracio de tots els vertexs del graf."""
        return self._nodes.__iter__( )

    def edges(self,x):
        """Return una iteracio de tots els edges de x al graf."""
        return self._out[x].__iter__()

    def edges_out(self, uuid):
        return self._out.get(uuid)
        
    def edges_in(self, uuid):
        return self._in.get(uuid)
    
    def minDistance(self, dist, visitat):
        minim = math.inf
        res = ""
        for node,distancia in dist.items():
            if node not in visitat and distancia < minim:
                minim = distancia
                res = node
        return res
    
    def dijkstra(self,n):
        dist={nAux:math.inf for nAux in self._out}
        visitat = {}
        dist[n] = 0
        predecessor = {}
        for count in range(len(self._nodes)-1):
            nveiAct = self.minDistance(dist, visitat)
            visitat[nveiAct] = True
            if nveiAct in self._out:
                for n2,p2 in self._out[nveiAct].items():
                    if (n2 not in visitat):
                        if (dist[nveiAct] + p2 < dist[n2]):
                            dist[n2] = dist[nveiAct] + p2
                            predecessor[n2] = nveiAct
        return dist, predecessor
    
    def camiMesCurt(self,n1, n2):
        try:
            cami = [ ]
            if n1 in self._nodes and n2 in self._nodes:
                dist,predecessor=self.dijkstra(n1)
                if n2 in predecessor:
                    cami.append(n2)
                    nodeAct = n2
                    while not nodeAct == n1:
                        vei = predecessor[nodeAct]
                        cami.append(vei)
                        nodeAct = vei
                    cami.reverse( )
            return cami
        except Exception as e:
            print("ERROR:", e)

    
    def __getitem__(self, key):
        if key not in self._nodes:
            return None
        else:
            return self._nodes[key]
    
    def __delitem__(self, key):
        try:
            del self._nodes[key]
        except Exception:
            print(f"No es pot borrar valor amb clau {key}")
        
        
    def __contains__(self, key):
        return key in self._nodes
        
    def get(self, key):
        return self._nodes.get(key)
    
    def uuid_in(self, key):
        return key in self._in
        
    def uuid_out(self, key):
        return key in self._out
    
    def get_in(self, key):
        return self._in[key]
    
    def get_out(self, key):
        return self._out[key]
    
    def __len__(self):
        return len(self._nodes)
    
    def __iter__(self):
        for node in self._nodes:
            yield node
    
    def __str__(self):
        cad="===============GRAF===================\n"
     
        for it in self._out.items():
            cad1="__________________________________________________________________________________\n"
            cad1=cad1+str(it[0])+" : "
            for valor in it[1].items():
                cad1=cad1+str(str(valor[0])+"("+ str(valor[1])+")"+" , " )
                            
            cad = cad + cad1 + "\n"
        
        return cad
    
    nodes = property(lambda self: self._nodes)