# -*- coding: utf-8 -*-
"""
GrafHash.py : ** REQUIRED ** El vostre codi de la classe GrafHash.
"""
def GrafHash():
    pass