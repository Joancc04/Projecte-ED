import cfg
from MusicID import MusicID
import eyed3
import numpy
import sys
import os
from ElementData import ElementData

# ==== FUNC 3 ====
class MusicData:
    class Song(ElementData):
        def __init__(self, file: str, uuid: str):
            super().__init__()
            self._file: str = file
            self._uuid: str = uuid
            super().load_MetaData(file)
        
        def print(self):
            print(f'''
#============================| {self.title} |=======================#
Duració: \t{self.duration} segons
Artista: \t{self.artist}
Àlbum:   \t{self.album}
Gènere: \t{self.genre}           
''')
        
        def print(self):
            print('ha', end='')
        file = property(lambda self: self._file)
    # ________________FI DE SUBLCLASSES_____________________________________________________________________
    
    __slots__ = '_songs'

    def __init__(self):
        self._songs: dict = {}

    def add_song(self, uuid: str, file_path: str = None):
        print("BEFORE", file_path)
        if file_path != "":
            #file_path = cfg.get_canonical_pathfile(file_path)[2:]
            3
        else:
            print("BSSSS: ", file_path)
            return
        print("AFTA", file_path)
        if os.path.exists(file_path):
            print("EXISTS VAMOOOO", file_path)
            self._songs[uuid] = self.Song( file=file_path,
                                           uuid=uuid )
        else:
            print("FAKEEEEE", file_path)
        
    
    def load_metadata(self, uuid):
        pass
    
    def remove_song(self, uuid: str):
        try: 
            del self._songs[uuid]
        except: 
            print("UUID given does not exist")
    
        
    def get_title(self, uuid):
        try:
            song = self._songs[uuid]
        except Exception:
            return ''
        else:
            return song.title
    
    def get_album(self, uuid):
        try:
            song = self._songs[uuid]
        except Exception:
            return ''
        else:
            return song.album
    
    def get_artist(self, uuid):
        try:
            song = self._songs[uuid]
        except Exception:
            return ''
        else:
            return song.artist
    
    def get_genre(self, uuid):
        try:
            song = self._songs[uuid]
        except Exception:
            return ''
        else:
            return song.genre
    
    def get_filename(self, uuid):
        try:
            song = self._songs[uuid]
        except Exception:
            return ''
        else:
            return song.file
    
    def get_duration(self, uuid):
        try:
            song = self._songs[uuid]
        except Exception:
            return ''
        else:
            return song.duration
    
    def show_info(self, uuid: str):
        try:
            self._songs[uuid].print()
            #print(f"[ UUID: {uuid[:11]}... | file_path: {self._songs[uuid].file}]")
        except KeyError:
            return ''
            
    def get_uuid(self, file: str) -> str:
        return self._Music_ID.get_uuid(file)

    def get_path(self, uuid: str) -> str:
        return self._Music_ID.get_path(uuid)
    
    def exists_file(self, given_file: str) -> bool:
        return True if given_file in [song.file for _, song in self._songs.items()] else False
    
    def __len__(self):
        return len(self._songs.keys())
    '''
    def __iter__(self):
        for key in self._songs:
            yield key
    '''
        
    songs = property(lambda self: list(self._songs.items()))