# -*- coding: utf-8 -*-
"""
ElementData.py : ** REQUIRED ** El vostre codi de la classe ElementData.
"""
import numpy
import eyed3
import sys
import cfg
import os


class ElementData:
    __slots__ = ["_title", "_artist", "_album", "_genre", "_duration", "_filename"]

    def __init__(self, title = None, filename = None, artist = None, album = None, genre = None, duration = None):
        self._title = title
        self._artist = artist
        self._album = album
        self._genre = genre
        self._duration = duration
        self._filename = filename
    
    def load_MetaData(self, file: str):
        metadata = eyed3.load(cfg.get_canonical_pathfile(file))
        if metadata is None:
            print("ERROR: Arxiu MP3 erroni!")
            sys.exit(1)
        
        try:
            genre = metadata.tag.genre.name
        except Exception:
            self._genre = "None"
        else:
            self._genre = genre
    
    def __hash__(self):
        return hash(self._filename)
    
    def __eq__(self, altre):
        return self._filename == altre.filename
    
    def __ne__(self, altre):
        return self._filename != altre.filename
    
    def __lt__(self, altre):
        return self._filename > altre.filename
    title = property(lambda self: self._title)
    artist = property(lambda self: self._artist)
    album = property(lambda self: self._album)
    genre = property(lambda self: self._genre)
    duration = property(lambda self: self._duration)
    filename = property(lambda self: self._filename)
